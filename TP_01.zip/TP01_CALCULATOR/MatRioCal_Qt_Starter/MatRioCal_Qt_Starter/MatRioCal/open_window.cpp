
#include "open_window.h"

#include <QFile>
#include <QTextStream>
#include <QApplication>
#include <QComboBox>
#include <QDoubleSpinBox>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QInputDialog>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QSpinBox>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>
#include <QWidget>
#include <QFrame>
#include <QAbstractItemView>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QLineEdit>
#include <cmath>

namespace
{
const QString DARK_BLUE   = "#142B55";
const QString DEEP_BLUE   = "#0A1C38";
const QString BABY_BLUE   = "#A7D8F0";
const QString BABY_PURPLE = "#D0B7F0";
const QString BORDER_BLUE = "#2D6FA5";
const QString LIGHT_TEXT  = "#EAF4FF";

QPushButton *makeButton(const QString &text,
                        const QString &objectName = QString())
{
    auto *button = new QPushButton(text);
    button->setMinimumHeight(40);
    button->setCursor(Qt::PointingHandCursor);
    button->setFocusPolicy(Qt::NoFocus);

    if (!objectName.isEmpty())
        button->setObjectName(objectName);

    return button;
}

QFrame *makePanel(const QString &name)
{
    auto *panel = new QFrame;
    panel->setObjectName(name);
    panel->setFrameShape(QFrame::StyledPanel);
    return panel;
}

QLabel *makeSectionTitle(const QString &text)
{
    auto *label = new QLabel(text);
    label->setObjectName("sectionTitle");
    return label;
}

QVector<double> parseVector(const QString &text, int expectedSize, bool &ok)
{
    QVector<double> values;
    const QStringList parts =
        text.split(QRegularExpression("[,;\\s]+"), Qt::SkipEmptyParts);

    ok = parts.size() == expectedSize;

    if (!ok)
        return values;

    for (const QString &part : parts) {
        bool numberOk = false;
        double value = part.toDouble(&numberOk);

        if (!numberOk || !std::isfinite(value)) {
            ok = false;
            return {};
        }

        values.append(value);
    }

    return values;
}
}

Openwindow::Openwindow(QWidget *parent)
    : QMainWindow(parent)
{
    darkMode = true;
    setWindowTitle("MatRioCal | Matrix Operations Calculator");
    resize(1500, 980);
    setMinimumSize(1120, 760);

    matrixA = MatrixLogic::createMatrix(4, 4);

    auto *central = new QWidget(this);
    central->setObjectName("centralWidget");
    setCentralWidget(central);

    auto *root = new QVBoxLayout(central);
    root->setContentsMargins(14, 10, 14, 10);
    root->setSpacing(12);

    // HEADER
    auto *header = makePanel("headerPanel");
    auto *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(16, 8, 16, 8);
    auto *modeButton = makeButton("☀ Light Mode");
    modeButton->setObjectName("modeButton");
    headerLayout->addWidget(modeButton);
    headerLayout->addStretch();
    connect(modeButton, &QPushButton::clicked, this, [this, modeButton]() {

        if (darkMode) {
            loadStyleSheet(":/lightMode.qss");
            darkMode = false;
            modeButton->setText("☾Night Mode");
        }
        else {
            loadStyleSheet(":/nightMode.qss");
            darkMode = true;
            modeButton->setText("☀ Light Mode");
        }

    });
    auto *modeLabel = new QLabel("Matrix operations calculator");
    modeLabel->setObjectName("subtitle");
    headerLayout->addWidget(modeLabel);
    root->addWidget(header);

    // MAIN THREE-COLUMN AREA
    auto *mainRow = new QHBoxLayout;
    mainRow->setSpacing(12);
    root->addLayout(mainRow, 1);

    // LEFT: MATRIX OPERATIONS
    auto *operationsPanel = makePanel("operationsPanel");
    auto *operationsLayout = new QVBoxLayout(operationsPanel);
    operationsLayout->setContentsMargins(12, 12, 12, 12);
    operationsLayout->addWidget(makeSectionTitle("MATRIX OPERATIONS"));

    auto *operationGrid = new QGridLayout;
    operationGrid->setSpacing(7);

    const QStringList operationLabels = {
        "＋ Addition", "− Subtraction",
        "× Multiply", "T Transpose",
        "λ Scalar Multiply", "|A| Determinant",
        "Tr Trace", "A⁻¹ Inverse",
        "r Rank", "Aⁿ Matrix Power",
        "▦ Diagonal Matrix"
    };

    for (int i = 0; i < operationLabels.size(); ++i) {
        auto *button = makeButton(operationLabels[i]);
        button->setProperty("buttonClass",
                            (i == 0 || i == 1 || i == 10)
                                ? "primary" : "primary");
        operationGrid->addWidget(button, i / 2, i % 2);

        connect(button, &QPushButton::clicked, this,
                [this, label = operationLabels[i]]() {
                    if (label.contains("Addition"))
                        addMatrices();
                    else if (label.contains("Subtraction"))
                        subtractMatrices();
                    else if (label.contains("Multiply"))
                        multiplyMatrices();
                    else if (label.contains("Transpose"))
                        transposeMatrix();
                    else if (label.contains("Scalar"))
                        scalarMultiplyMatrix();
                    else if (label.contains("Determinant"))
                        calculateDeterminant();
                    else if (label.contains("Trace"))
                        calculateTrace();
                    else if (label.contains("Inverse"))
                        calculateInverse();
                    else if (label.contains("Rank"))
                        calculateRank();
                    else if (label.contains("Matrix Power"))
                        calculatePower();
                    else if (label.contains("Diagonal"))
                        createDiagonalMatrix();
                });
    }

    operationsLayout->addLayout(operationGrid);
    operationsLayout->addStretch();
    mainRow->addWidget(operationsPanel, 27);

    // CENTER: MATRIX TABLE
    auto *matrixPanel = makePanel("matrixPanel");
    auto *matrixLayout = new QVBoxLayout(matrixPanel);
    matrixLayout->setContentsMargins(12, 12, 12, 12);
    matrixLayout->addWidget(makeSectionTitle("MATRIX WORKSPACE"));

    auto *toolbar = new QHBoxLayout;

    matrixSelector = new QComboBox;
    matrixSelector->addItem("Matrix A");
    matrixSelector->setMinimumHeight(36);

    auto *addMatrixButton = makeButton("＋ Add Matrix");
    addMatrixButton->setProperty("buttonClass", "purple");

    rowsSpin = new QSpinBox;
    colsSpin = new QSpinBox;

    rowsSpin->setRange(1, 20);
    colsSpin->setRange(1, 20);
    rowsSpin->setValue(4);
    colsSpin->setValue(4);
    rowsSpin->setPrefix("Rows ");
    colsSpin->setPrefix("Cols ");
    rowsSpin->setMinimumHeight(36);
    colsSpin->setMinimumHeight(36);

    toolbar->addWidget(matrixSelector, 1);
    toolbar->addWidget(addMatrixButton);
    toolbar->addWidget(rowsSpin);
    toolbar->addWidget(colsSpin);
    matrixLayout->addLayout(toolbar);

    matrixSizeLabel = new QLabel("4 × 4");
    matrixSizeLabel->setObjectName("matrixSizeLabel");
    matrixLayout->addWidget(matrixSizeLabel);

    matrixTable = new QTableWidget(4, 4);
    matrixTable->setObjectName("matrixTable");
    matrixTable->setMinimumHeight(0);
    matrixTable->setSelectionMode(QAbstractItemView::SingleSelection);
    matrixTable->setSelectionBehavior(QAbstractItemView::SelectItems);
    matrixTable->setEditTriggers(
        QAbstractItemView::DoubleClicked |
        QAbstractItemView::EditKeyPressed |
        QAbstractItemView::AnyKeyPressed);
    matrixTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    matrixTable->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    matrixTable->verticalHeader()->setDefaultSectionSize(50);
    matrixTable->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    matrixTable->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    matrixTable->setAlternatingRowColors(true);

    writeMatrixToTable(matrixA);
    matrixLayout->addWidget(matrixTable, 1);

    mainRow->addWidget(matrixPanel, 52);

    // RIGHT: LINEAR-SYSTEM SOLVERS
    auto *solverPanel = makePanel("solverPanel");
    auto *solverLayout = new QVBoxLayout(solverPanel);
    solverLayout->setContentsMargins(12, 12, 12, 12);
    solverLayout->addWidget(makeSectionTitle("DIRECT SOLVERS"));

    const QStringList directLabels = {
        "Cramer's Rule",
        "Factorization (Gaussian)",
        "LU Decomposition"
    };

    for (const QString &label : directLabels) {
        auto *button = makeButton(label);
        button->setProperty("buttonClass", "purple");
        solverLayout->addWidget(button);

        connect(button, &QPushButton::clicked, this,
                [this, label]() {
                    if (label == "Cramer's Rule")
                        runSolver("cramer");
                    else if (label == "LU Decomposition")
                        runSolver("lu");
                    else
                        runSolver("gaussian");
                });
    }

    auto *separator = new QFrame;
    separator->setFrameShape(QFrame::HLine);
    separator->setObjectName("separator");
    solverLayout->addWidget(separator);

    solverLayout->addWidget(makeSectionTitle("ITERATIVE SOLVERS"));

    const QStringList iterativeLabels = {
        "⟳ Jacobi",
        "⟳ Gauss–Seidel",
        "ω Relaxation"
    };

    for (const QString &label : iterativeLabels) {
        auto *button = makeButton(label);
        button->setProperty("buttonClass", "purple");
        solverLayout->addWidget(button);

        connect(button, &QPushButton::clicked, this,
                [this, label]() {
                    if (label.contains("Jacobi"))
                        runSolver("jacobi");
                    else if (label.contains("Seidel"))
                        runSolver("seidel");
                    else
                        runSolver("relaxation");
                });
    }

    solverLayout->addStretch();
    mainRow->addWidget(solverPanel, 23);

    // BOTTOM: NUMERIC KEYPAD
    auto *keypadPanel = makePanel("keypadPanel");
    auto *keypadLayout = new QHBoxLayout(keypadPanel);
    keypadLayout->setContentsMargins(12, 10, 12, 10);
    keypadLayout->setSpacing(7);

    auto *keyGrid = new QGridLayout;
    keyGrid->setSpacing(6);

    const QStringList keys = {
        "7", "8", "9", "÷",
        "4", "5", "6", "×",
        "1", "2", "3", "−",
        "0", ".", "=", "+"
    };

    for (int i = 0; i < keys.size(); ++i) {
        auto *button = makeButton(keys[i]);
        button->setProperty("buttonClass",
                            QString("0123456789.=").contains(keys[i])
                                ? "primary" : "purple");

        keyGrid->addWidget(button, i / 4, i % 4);
        connect(button, &QPushButton::clicked, this,
                [this, key = keys[i]]() {
                    if (key.size() == 1 && key[0].isDigit())
                        insertNumber(key);
                    else if (key == ".")
                        insertDecimal();
                    else if (key == "=")
                        calculateInput();
                    else if (key == "+" || key == "−"
                             || key == "×" || key == "÷") {
                        if (entryBuffer.isEmpty()) {
                            bool ok = false;
                            double value = currentMatrix().isEmpty()
                                               ? 0.0 : 0.0;
                            Q_UNUSED(value);
                            if (matrixTable->currentItem())
                                value = matrixTable->currentItem()->text().toDouble(&ok);
                            if (!ok) {
                                showMessage("Keypad",
                                            "Select a cell containing a number first.");
                                return;
                            }
                            entryBuffer = QString::number(value, 'g', 15);
                        }

                        bool ok = false;
                        firstOperand = entryBuffer.toDouble(&ok);
                        if (!ok)
                            return;

                        pendingOperator = key;
                        entryBuffer.clear();
                        waitingForOperand = true;
                        updateStatus("Enter the second operand, then press =.");
                    }
                });
    }

    keypadLayout->addLayout(keyGrid, 4);

    auto *editGrid = new QGridLayout;
    auto *clearButton = makeButton("C");
    auto *backspaceButton = makeButton("⌫");
    inputDisplay = new QLineEdit;
    inputDisplay->setReadOnly(true);
    inputDisplay->setPlaceholderText("Input");
    inputDisplay->setAlignment(Qt::AlignRight);
    inputDisplay->setMinimumHeight(50);
    inputDisplay->setObjectName("inputDisplay");
    clearButton->setProperty("buttonClass", "purple");
    backspaceButton->setProperty("buttonClass", "purple");

    editGrid->addWidget(clearButton, 0, 0);
    editGrid->addWidget(backspaceButton, 0, 1);
    editGrid->addWidget(inputDisplay, 1, 0, 1, 2);
    editGrid->setAlignment(Qt::AlignTop);
    keypadLayout->addLayout(editGrid, 1);
    root->addWidget(keypadPanel);

    // FOOTER
    auto *footer = new QHBoxLayout;
    auto *footerText = new QLabel("MatRioCal | Matrix Calculator");
    footerText->setObjectName("subtitle");

    statusLabel = new QLabel("● Ready");
    statusLabel->setObjectName("statusLabel");

    footer->addWidget(footerText);
    footer->addStretch();
    footer->addWidget(statusLabel);
    root->addLayout(footer);

    connect(rowsSpin, qOverload<int>(&QSpinBox::valueChanged),
            this, [this](int) {
                resizeMatrixGrid(rowsSpin->value(), colsSpin->value());
            });

    connect(colsSpin, qOverload<int>(&QSpinBox::valueChanged),
            this, [this](int) {
                resizeMatrixGrid(rowsSpin->value(), colsSpin->value());
            });

    connect(matrixSelector, &QComboBox::currentTextChanged,
            this, &Openwindow::loadMatrix);

    connect(addMatrixButton, &QPushButton::clicked, this, [this]() {
        if (hasMatrixB) {
            showMessage("Matrix B", "Matrix B already exists.");
            return;
        }

        saveCurrentMatrix();
        matrixB = MatrixLogic::createMatrix(
            rowsSpin->value(), colsSpin->value());
        hasMatrixB = true;
        matrixSelector->addItem("Matrix B");
        matrixSelector->setCurrentText("Matrix B");
        writeMatrixToTable(matrixB);
        updateStatus("Matrix B created.");
    });

    connect(clearButton, &QPushButton::clicked,
            this, &Openwindow::clearCurrentCell);

    connect(backspaceButton, &QPushButton::clicked,
            this, &Openwindow::backspaceCurrentCell);

    connect(modeButton, &QPushButton::clicked, this, [this, modeButton]() {

        lightMode = !lightMode;

        if (lightMode)
            modeButton->setText("☾ Night Mode");
        else
            modeButton->setText("☀ Light Mode");
    });

    connectOperationButtons();
    connectInputButtons();
    connectSolverButtons();
    updateStatus("Ready.");
}

void Openwindow::connectOperationButtons() {}
void Openwindow::connectInputButtons() {}
void Openwindow::connectSolverButtons() {}

MatrixLogic::Matrix& Openwindow::currentMatrix()
{
    return matrixSelector->currentText() == "Matrix B"
               ? matrixB : matrixA;
}

void Openwindow::saveCurrentMatrix()
{
    bool ok = false;
    MatrixLogic::Matrix values = readMatrixFromTable(ok);

    if (ok) {
        if (matrixSelector->currentText() == "Matrix B")
            matrixB = values;
        else
            matrixA = values;
    }
}

void Openwindow::loadMatrix(const QString& name)
{
    saveCurrentMatrix();

    if (name == "Matrix B" && hasMatrixB)
        writeMatrixToTable(matrixB);
    else
        writeMatrixToTable(matrixA);

    const MatrixLogic::Matrix &M = currentMatrix();

    if (!M.isEmpty()) {
        rowsSpin->blockSignals(true);
        colsSpin->blockSignals(true);
        rowsSpin->setValue(M.size());
        colsSpin->setValue(M[0].size());
        rowsSpin->blockSignals(false);
        colsSpin->blockSignals(false);
        matrixSizeLabel->setText(
            QString("%1 × %2").arg(M.size()).arg(M[0].size()));
    }

    updateStatus(name + " selected.");
}

MatrixLogic::Matrix Openwindow::readMatrixFromTable(bool &ok)
{
    MatrixLogic::Matrix result = MatrixLogic::createMatrix(
        matrixTable->rowCount(), matrixTable->columnCount());

    ok = true;

    for (int i = 0; i < matrixTable->rowCount(); ++i) {
        for (int j = 0; j < matrixTable->columnCount(); ++j) {
            QTableWidgetItem *item = matrixTable->item(i, j);

            if (!item || item->text().trimmed().isEmpty()) {
                result[i][j] = 0.0;
                continue;
            }

            bool numberOk = false;
            double value = item->text().trimmed().toDouble(&numberOk);

            if (!numberOk || !std::isfinite(value)) {
                ok = false;
                showMessage("Invalid matrix entry",
                            QString("Cell (%1, %2) must contain a valid number.")
                                .arg(i + 1).arg(j + 1));
                return {};
            }

            result[i][j] = value;
        }
    }

    return result;
}
void Openwindow::loadStyleSheet(const QString& fileName)
{
    QFile file(fileName);

    if (file.open(QFile::ReadOnly | QFile::Text)) {
        QTextStream stream(&file);
        QString styleSheet = stream.readAll();
        qApp->setStyleSheet(styleSheet);
        file.close();
    }
}

void Openwindow::writeMatrixToTable(const MatrixLogic::Matrix& M)
{
    if (!MatrixLogic::isValidMatrix(M))
        return;

    matrixTable->setRowCount(M.size());
    matrixTable->setColumnCount(M[0].size());

    for (int i = 0; i < M.size(); ++i) {
        for (int j = 0; j < M[i].size(); ++j) {
            auto *item = new QTableWidgetItem(
                QString::number(M[i][j], 'g', 10));
            item->setTextAlignment(Qt::AlignCenter);
            matrixTable->setItem(i, j, item);
        }
    }

    matrixSizeLabel->setText(
        QString("%1 × %2").arg(M.size()).arg(M[0].size()));
}

void Openwindow::resizeMatrixGrid(int rows, int cols)
{
    saveCurrentMatrix();

    MatrixLogic::Matrix old = currentMatrix();
    MatrixLogic::Matrix resized = MatrixLogic::createMatrix(rows, cols);

    for (int i = 0; i < qMin(rows, old.size()); ++i) {
        for (int j = 0; j < qMin(cols, old[i].size()); ++j)
            resized[i][j] = old[i][j];
    }

    currentMatrix() = resized;
    writeMatrixToTable(resized);
    updateStatus("Matrix resized to " +
                 QString::number(rows) + " × " + QString::number(cols) + ".");
}

void Openwindow::showMessage(const QString& title, const QString& message)
{
    QMessageBox::information(this, title, message);
}

void Openwindow::updateStatus(const QString& message)
{
    if (statusLabel)
        statusLabel->setText("● " + message);
}

void Openwindow::showMatrixResult(const QString& title,
                                  const MatrixLogic::Matrix& result)
{
    if (!MatrixLogic::isValidMatrix(result)) {
        showMessage(title, "The operation failed. Check matrix dimensions and values.");
        return;
    }

    saveCurrentMatrix();

    if (QMessageBox::question(
            this, title,
            "Result:\n\n" + MatrixLogic::matrixToString(result)
                + "\nReplace the current matrix with this result?",
            QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes) {
        currentMatrix() = result;
        writeMatrixToTable(result);

        rowsSpin->blockSignals(true);
        colsSpin->blockSignals(true);
        rowsSpin->setValue(result.size());
        colsSpin->setValue(result[0].size());
        rowsSpin->blockSignals(false);
        colsSpin->blockSignals(false);
    }

    updateStatus(title + " complete.");
}

void Openwindow::addMatrices()
{
    saveCurrentMatrix();

    if (!hasMatrixB) {
        showMessage("Addition", "Create Matrix B first.");
        return;
    }

    showMatrixResult("A + B", MatrixLogic::add(matrixA, matrixB));
}

void Openwindow::subtractMatrices()
{
    saveCurrentMatrix();

    if (!hasMatrixB) {
        showMessage("Subtraction", "Create Matrix B first.");
        return;
    }

    showMatrixResult("A - B", MatrixLogic::subtract(matrixA, matrixB));
}

void Openwindow::multiplyMatrices()
{
    saveCurrentMatrix();

    if (!hasMatrixB) {
        showMessage("Multiplication", "Create Matrix B first.");
        return;
    }

    showMatrixResult("A × B", MatrixLogic::multiply(matrixA, matrixB));
}

void Openwindow::transposeMatrix()
{
    saveCurrentMatrix();
    showMatrixResult("Transpose", MatrixLogic::transpose(currentMatrix()));
}

void Openwindow::scalarMultiplyMatrix()
{
    bool ok = false;
    double scalar = QInputDialog::getDouble(
        this, "Scalar multiplication", "Enter scalar:",
        2.0, -1e9, 1e9, 6, &ok);

    if (!ok)
        return;

    saveCurrentMatrix();
    showMatrixResult("Scalar multiplication",
                     MatrixLogic::scalarMultiply(currentMatrix(), scalar));
}

void Openwindow::calculateDeterminant()
{
    saveCurrentMatrix();
    double value = MatrixLogic::determinant(currentMatrix());

    if (!std::isfinite(value)) {
        showMessage("Determinant", "The determinant requires a square matrix.");
        return;
    }

    showMessage("Determinant", "det(A) = " + QString::number(value, 'g', 12));
}

void Openwindow::calculateTrace()
{
    saveCurrentMatrix();
    double value = MatrixLogic::trace(currentMatrix());

    if (!std::isfinite(value)) {
        showMessage("Trace", "Trace requires a square matrix.");
        return;
    }

    showMessage("Trace", "tr(A) = " + QString::number(value, 'g', 12));
}

void Openwindow::calculateRank()
{
    saveCurrentMatrix();
    int value = MatrixLogic::rank(currentMatrix());

    if (value < 0) {
        showMessage("Rank", "The matrix contains invalid data.");
        return;
    }

    showMessage("Rank", "rank(A) = " + QString::number(value));
}

void Openwindow::calculateInverse()
{
    saveCurrentMatrix();
    MatrixLogic::Matrix result = MatrixLogic::inverse(currentMatrix());

    if (result.isEmpty()) {
        showMessage("Inverse", "The matrix is not square or is singular.");
        return;
    }

    showMatrixResult("Inverse", result);
}

void Openwindow::calculatePower()
{
    bool ok = false;
    int exponent = QInputDialog::getInt(
        this, "Matrix power", "Enter integer exponent:",
        2, -20, 20, 1, &ok);

    if (!ok)
        return;

    saveCurrentMatrix();
    showMatrixResult("Matrix power",
                     MatrixLogic::power(currentMatrix(), exponent));
}

void Openwindow::createDiagonalMatrix()
{
    saveCurrentMatrix();

    const MatrixLogic::Matrix M = currentMatrix();

    if (!MatrixLogic::isValidMatrix(M)) {
        showMessage("Diagonal matrix", "Enter a valid matrix first.");
        return;
    }

    QVector<double> diagonal;

    for (int i = 0; i < qMin(M.size(), M[0].size()); ++i)
        diagonal.append(M[i][i]);

    showMatrixResult("Diagonal matrix",
                     MatrixLogic::diagonalMatrix(diagonal));
}

void Openwindow::setCurrentCellValue(double value)
{
    if (!matrixTable->currentItem()) {
        if (matrixTable->rowCount() == 0 || matrixTable->columnCount() == 0)
            return;

        matrixTable->setCurrentCell(0, 0);
    }

    QTableWidgetItem *item = matrixTable->currentItem();

    if (!item) {
        item = new QTableWidgetItem;
        matrixTable->setItem(matrixTable->currentRow(),
                             matrixTable->currentColumn(), item);
    }

    item->setText(QString::number(value, 'g', 12));
    saveCurrentMatrix();
}

void Openwindow::insertNumber(const QString& number)
{
    if (waitingForOperand) {
        entryBuffer.clear();
        waitingForOperand = false;
    }

    entryBuffer += number;
    inputDisplay->setText(entryBuffer);
    updateStatus("Input: " + entryBuffer);
}

void Openwindow::insertDecimal()
{
    if (waitingForOperand) {
        entryBuffer.clear();
        waitingForOperand = false;
    }

    if (!entryBuffer.contains('.'))
        entryBuffer += entryBuffer.isEmpty() ? "0." : ".";
    inputDisplay->setText(entryBuffer);
    updateStatus("Input: " + entryBuffer);
}

void Openwindow::insertSign()
{
    if (entryBuffer.startsWith('-'))
        entryBuffer.remove(0, 1);
    else
        entryBuffer.prepend('-');
    inputDisplay->setText(entryBuffer);
    updateStatus("Input: " + entryBuffer);
}

void Openwindow::clearCurrentCell()
{
    entryBuffer.clear();
    pendingOperator.clear();
    waitingForOperand = false;

    if (matrixTable->currentItem())
        matrixTable->currentItem()->setText("0");

    saveCurrentMatrix();
    updateStatus("Input cleared.");
}

void Openwindow::backspaceCurrentCell()
{
    if (!entryBuffer.isEmpty()) {
        entryBuffer.chop(1);
        updateStatus("Input: " + entryBuffer);
        return;
    }

    if (matrixTable->currentItem()) {
        QString text = matrixTable->currentItem()->text();
        text.chop(1);
        matrixTable->currentItem()->setText(text);
        saveCurrentMatrix();
    }
}

void Openwindow::calculateInput()
{
    bool ok = false;

    if (entryBuffer.isEmpty()) {
        showMessage("Keypad", "Enter a number using the keypad first.");
        return;
    }

    double secondOperand = entryBuffer.toDouble(&ok);

    if (!ok || !std::isfinite(secondOperand)) {
        showMessage("Keypad", "The entered value is not a valid number.");
        return;
    }

    if (!pendingOperator.isEmpty()) {
        double result = 0.0;

        if (pendingOperator == "+")
            result = firstOperand + secondOperand;
        else if (pendingOperator == "−")
            result = firstOperand - secondOperand;
        else if (pendingOperator == "×")
            result = firstOperand * secondOperand;
        else if (pendingOperator == "÷") {
            if (std::abs(secondOperand) < 1e-12) {
                showMessage("Keypad", "Division by zero is not allowed.");
                return;
            }
            result = firstOperand / secondOperand;
        }

        if (!std::isfinite(result)) {
            showMessage("Keypad", "The result is outside the supported range.");
            return;
        }

        setCurrentCellValue(result);
        pendingOperator.clear();
        entryBuffer = QString::number(result, 'g', 12);
        waitingForOperand = true;
        updateStatus("Result written to selected cell.");
        return;
    }

    setCurrentCellValue(secondOperand);
    waitingForOperand = true;
    updateStatus("Value written to selected cell.");
}

QVector<double> Openwindow::getVectorB(int size, bool &ok)
{
    bool inputOk = false;

    QString text = QInputDialog::getText(
        this, "Right-hand-side vector",
        QString("Enter %1 values for vector b, separated by commas:")
            .arg(size),
        QLineEdit::Normal, QString(), &inputOk);

    if (!inputOk) {
        ok = false;
        return {};
    }

    QVector<double> values = parseVector(text, size, ok);

    if (!ok)
        showMessage("Vector input",
                    QString("Please enter exactly %1 valid numeric values.").arg(size));

    return values;
}

void Openwindow::showVectorResult(
    const QString& title, const MatrixLogic::SolverResult& result)
{
    QString message = result.message;

    if (!result.solution.isEmpty()) {
        message += "\n\nSolution:\n";

        for (int i = 0; i < result.solution.size(); ++i) {
            message += QString("x%1 = %2\n")
            .arg(i + 1)
                .arg(result.solution[i], 0, 'g', 12);
        }
    }

    if (result.iterations > 0)
        message += QString("\nIterations: %1").arg(result.iterations);

    QMessageBox::information(this, title, message);

    updateStatus(result.success ? "Solver completed." : "Solver did not converge or failed.");
}


void Openwindow::runSolver(const QString& method)
{
    saveCurrentMatrix();
    MatrixLogic::Matrix A = currentMatrix();

    if (!MatrixLogic::isSquare(A)) {
        showMessage("Linear solver", "Select a square matrix first.");
        return;
    }

    bool ok = false;
    QVector<double> b = getVectorB(A.size(), ok);

    if (!ok)
        return;

    MatrixLogic::SolverResult result;

    if (method == "cramer") {
        result = MatrixLogic::cramerRule(A, b);
    } else if (method == "gaussian") {
        result = MatrixLogic::gaussianElimination(A, b);
    } else if (method == "lu") {
        result = MatrixLogic::luDecomposition(A, b);
    } else {
        QVector<double> initialGuess(A.size(), 0.0);

        double tolerance = QInputDialog::getDouble(
            this, "Solver settings", "Tolerance:",
            0.000001, 1e-12, 1.0, 10, &ok);

        if (!ok)
            return;

        int iterations = QInputDialog::getInt(
            this, "Solver settings", "Maximum iterations:",
            100, 1, 100000, 1, &ok);

        if (!ok)
            return;

        if (method == "jacobi") {
            result = MatrixLogic::jacobi(
                A, b, initialGuess, iterations, tolerance);
        } else if (method == "seidel") {
            result = MatrixLogic::gaussSeidel(
                A, b, initialGuess, iterations, tolerance);
        } else {
            double omega = QInputDialog::getDouble(
                this, "Relaxation settings", "Relaxation factor ω (0 < ω < 2):",
                1.0, 0.01, 1.99, 2, &ok);

            if (!ok)
                return;

            result = MatrixLogic::relaxation(
                A, b, initialGuess, omega, iterations, tolerance);
        }
    }
    loadStyleSheet(":/nightMode.qss");

    showVectorResult("Linear-system solution", result);
}



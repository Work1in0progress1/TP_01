
#ifndef MATRIX_LOGIC_H
#define MATRIX_LOGIC_H

#include <QVector>
#include <QString>

namespace MatrixLogic
{
using Matrix = QVector<QVector<double>>;

struct SolverResult
{
    bool success = false;
    QVector<double> solution;
    int iterations = 0;
    QString message;
};

Matrix createMatrix(int rows, int cols);
bool isValidMatrix(const Matrix& A);
bool isSquare(const Matrix& A);
bool isSameSize(const Matrix& A, const Matrix& B);
bool isDiagonallyDominant(const Matrix& A);
bool isValidForLinearSystem(const Matrix& A, const QVector<double>& b);

QString matrixToString(const Matrix& A);

Matrix add(const Matrix& A, const Matrix& B);
Matrix subtract(const Matrix& A, const Matrix& B);
Matrix multiply(const Matrix& A, const Matrix& B);
Matrix scalarMultiply(const Matrix& A, double scalar);
Matrix transpose(const Matrix& A);
Matrix diagonalMatrix(const QVector<double>& values);
Matrix inverse(const Matrix& A);
Matrix power(const Matrix& A, int exponent);

double determinant(const Matrix& A);
double trace(const Matrix& A);
int rank(const Matrix& A);

SolverResult cramerRule(const Matrix& A, const QVector<double>& b);
SolverResult gaussianElimination(const Matrix& A, const QVector<double>& b);
SolverResult luDecomposition(const Matrix& A, const QVector<double>& b);

SolverResult jacobi(const Matrix& A, const QVector<double>& b,
                    const QVector<double>& initialGuess,
                    int maxIterations, double tolerance);

SolverResult gaussSeidel(const Matrix& A, const QVector<double>& b,
                         const QVector<double>& initialGuess,
                         int maxIterations, double tolerance);

SolverResult relaxation(const Matrix& A, const QVector<double>& b,
                        const QVector<double>& initialGuess,
                        double omega, int maxIterations, double tolerance);

double vectorError(const QVector<double>& oldVector,
                   const QVector<double>& newVector);

} // namespace MatrixLogic

#endif

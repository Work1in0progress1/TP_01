
#include "matrix_logic.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace MatrixLogic
{
namespace
{
const double EPS = 1e-10;

bool validSquare(const Matrix& A)
{
    return isSquare(A) && isValidMatrix(A);
}

bool solveLinear(Matrix A, QVector<double> b, QVector<double>& x)
{
    const int n = A.size();

    if (!isValidForLinearSystem(A, b))
        return false;

    for (int k = 0; k < n; ++k) {
        int pivot = k;

        for (int i = k + 1; i < n; ++i) {
            if (std::abs(A[i][k]) > std::abs(A[pivot][k]))
                pivot = i;
        }

        if (std::abs(A[pivot][k]) < EPS)
            return false;

        if (pivot != k) {
            A.swapItemsAt(pivot, k);
            std::swap(b[pivot], b[k]);
        }

        for (int i = k + 1; i < n; ++i) {
            double factor = A[i][k] / A[k][k];

            for (int j = k; j < n; ++j)
                A[i][j] -= factor * A[k][j];

            b[i] -= factor * b[k];
        }
    }

    x.fill(0.0, n);

    for (int i = n - 1; i >= 0; --i) {
        double sum = b[i];

        for (int j = i + 1; j < n; ++j)
            sum -= A[i][j] * x[j];

        if (std::abs(A[i][i]) < EPS)
            return false;

        x[i] = sum / A[i][i];
    }

    return true;
}

SolverResult iterativeSolve(
    const Matrix& A, const QVector<double>& b,
    const QVector<double>& initialGuess,
    int maxIterations, double tolerance,
    int method, double omega)
{
    SolverResult result;

    if (!isValidForLinearSystem(A, b)) {
        result.message = "A must be a square matrix matching vector b.";
        return result;
    }

    if (maxIterations < 1 || tolerance <= 0.0) {
        result.message = "Iterations and tolerance must be positive.";
        return result;
    }

    const int n = A.size();
    QVector<double> x = initialGuess;

    if (x.size() != n)
        x.fill(0.0, n);

    for (int i = 0; i < n; ++i) {
        if (std::abs(A[i][i]) < EPS) {
            result.message = "A zero diagonal entry prevents iteration.";
            return result;
        }
    }

    if (method == 2 && (omega <= 0.0 || omega >= 2.0)) {
        result.message = "Relaxation requires 0 < omega < 2.";
        return result;
    }

    for (int iteration = 1; iteration <= maxIterations; ++iteration) {
        QVector<double> old = x;

        for (int i = 0; i < n; ++i) {
            double sum = b[i];

            for (int j = 0; j < n; ++j) {
                if (i == j)
                    continue;

                double value = A[i][j];

                if (method == 0)
                    sum -= value * old[j];
                else
                    sum -= value * x[j];
            }

            double next = sum / A[i][i];

            if (method == 0) {
                x[i] = next; // Jacobi uses only old values above.
            } else if (method == 1) {
                x[i] = next; // Gauss-Seidel uses updated values.
            } else {
                x[i] = (1.0 - omega) * old[i] + omega * next;
            }
        }

        result.iterations = iteration;

        if (vectorError(old, x) < tolerance) {
            result.success = true;
            result.solution = x;
            result.message = "Converged successfully.";
            return result;
        }
    }

    result.solution = x;
    result.message = "Maximum iterations reached; convergence was not achieved.";
    return result;
}
} // anonymous namespace

Matrix createMatrix(int rows, int cols)
{
    if (rows < 1 || cols < 1)
        return {};

    return Matrix(rows, QVector<double>(cols, 0.0));
}

bool isValidMatrix(const Matrix& A)
{
    if (A.isEmpty() || A[0].isEmpty())
        return false;

    const int cols = A[0].size();

    for (const auto& row : A) {
        if (row.size() != cols)
            return false;

        for (double value : row) {
            if (!std::isfinite(value))
                return false;
        }
    }

    return true;
}

bool isSquare(const Matrix& A)
{
    return !A.isEmpty() && A.size() == A[0].size();
}

bool isSameSize(const Matrix& A, const Matrix& B)
{
    return isValidMatrix(A) && isValidMatrix(B)
    && A.size() == B.size()
        && A[0].size() == B[0].size();
}

bool isDiagonallyDominant(const Matrix& A)
{
    if (!validSquare(A))
        return false;

    for (int i = 0; i < A.size(); ++i) {
        double offDiagonal = 0.0;

        for (int j = 0; j < A.size(); ++j) {
            if (i != j)
                offDiagonal += std::abs(A[i][j]);
        }

        if (std::abs(A[i][i]) < offDiagonal)
            return false;
    }

    return true;
}

bool isValidForLinearSystem(const Matrix& A, const QVector<double>& b)
{
    if (!validSquare(A) || b.size() != A.size())
        return false;

    for (double value : b) {
        if (!std::isfinite(value))
            return false;
    }

    return true;
}

QString matrixToString(const Matrix& A)
{
    QString output;

    for (const auto& row : A) {
        QStringList values;

        for (double value : row)
            values << QString::number(value, 'g', 10);

        output += values.join("    ") + '\n';
    }

    return output;
}

Matrix add(const Matrix& A, const Matrix& B)
{
    if (!isSameSize(A, B))
        return {};

    Matrix result = A;

    for (int i = 0; i < A.size(); ++i)
        for (int j = 0; j < A[i].size(); ++j)
            result[i][j] += B[i][j];

    return result;
}

Matrix subtract(const Matrix& A, const Matrix& B)
{
    if (!isSameSize(A, B))
        return {};

    Matrix result = A;

    for (int i = 0; i < A.size(); ++i)
        for (int j = 0; j < A[i].size(); ++j)
            result[i][j] -= B[i][j];

    return result;
}

Matrix multiply(const Matrix& A, const Matrix& B)
{
    if (!isValidMatrix(A) || !isValidMatrix(B)
        || A[0].size() != B.size())
        return {};

    Matrix result = createMatrix(A.size(), B[0].size());

    for (int i = 0; i < A.size(); ++i) {
        for (int j = 0; j < B[0].size(); ++j) {
            for (int k = 0; k < B.size(); ++k)
                result[i][j] += A[i][k] * B[k][j];
        }
    }

    return result;
}

Matrix scalarMultiply(const Matrix& A, double scalar)
{
    if (!isValidMatrix(A) || !std::isfinite(scalar))
        return {};

    Matrix result = A;

    for (auto& row : result)
        for (double& value : row)
            value *= scalar;

    return result;
}

Matrix transpose(const Matrix& A)
{
    if (!isValidMatrix(A))
        return {};

    Matrix result = createMatrix(A[0].size(), A.size());

    for (int i = 0; i < A.size(); ++i)
        for (int j = 0; j < A[i].size(); ++j)
            result[j][i] = A[i][j];

    return result;
}

Matrix diagonalMatrix(const QVector<double>& values)
{
    if (values.isEmpty())
        return {};

    Matrix result = createMatrix(values.size(), values.size());

    for (int i = 0; i < values.size(); ++i)
        result[i][i] = values[i];

    return result;
}

double determinant(const Matrix& A)
{
    if (!validSquare(A))
        return std::numeric_limits<double>::quiet_NaN();

    const int n = A.size();
    Matrix temp = A;
    double det = 1.0;

    for (int k = 0; k < n; ++k) {
        int pivot = k;

        for (int i = k + 1; i < n; ++i) {
            if (std::abs(temp[i][k]) > std::abs(temp[pivot][k]))
                pivot = i;
        }

        if (std::abs(temp[pivot][k]) < EPS)
            return 0.0;

        if (pivot != k) {
            temp.swapItemsAt(pivot, k);
            det = -det;
        }

        double pivotValue = temp[k][k];
        det *= pivotValue;

        for (int i = k + 1; i < n; ++i) {
            double factor = temp[i][k] / pivotValue;

            for (int j = k + 1; j < n; ++j)
                temp[i][j] -= factor * temp[k][j];
        }
    }

    return det;
}

double trace(const Matrix& A)
{
    if (!validSquare(A))
        return std::numeric_limits<double>::quiet_NaN();

    double result = 0.0;

    for (int i = 0; i < A.size(); ++i)
        result += A[i][i];

    return result;
}

int rank(const Matrix& A)
{
    if (!isValidMatrix(A))
        return -1;

    Matrix temp = A;
    int pivotRow = 0;
    const int rows = temp.size();
    const int cols = temp[0].size();

    for (int col = 0; col < cols && pivotRow < rows; ++col) {
        int pivot = pivotRow;

        for (int i = pivotRow + 1; i < rows; ++i) {
            if (std::abs(temp[i][col]) > std::abs(temp[pivot][col]))
                pivot = i;
        }

        if (std::abs(temp[pivot][col]) < EPS)
            continue;

        temp.swapItemsAt(pivot, pivotRow);

        double divisor = temp[pivotRow][col];

        for (int j = col; j < cols; ++j)
            temp[pivotRow][j] /= divisor;

        for (int i = 0; i < rows; ++i) {
            if (i == pivotRow)
                continue;

            double factor = temp[i][col];

            for (int j = col; j < cols; ++j)
                temp[i][j] -= factor * temp[pivotRow][j];
        }

        ++pivotRow;
    }

    return pivotRow;
}

Matrix inverse(const Matrix& A)
{
    if (!validSquare(A))
        return {};

    const int n = A.size();
    Matrix temp = A;
    Matrix result = createMatrix(n, n);

    for (int i = 0; i < n; ++i)
        result[i][i] = 1.0;

    for (int k = 0; k < n; ++k) {
        int pivot = k;

        for (int i = k + 1; i < n; ++i) {
            if (std::abs(temp[i][k]) > std::abs(temp[pivot][k]))
                pivot = i;
        }

        if (std::abs(temp[pivot][k]) < EPS)
            return {};

        temp.swapItemsAt(pivot, k);
        result.swapItemsAt(pivot, k);

        double divisor = temp[k][k];

        for (int j = 0; j < n; ++j) {
            temp[k][j] /= divisor;
            result[k][j] /= divisor;
        }

        for (int i = 0; i < n; ++i) {
            if (i == k)
                continue;

            double factor = temp[i][k];

            for (int j = 0; j < n; ++j) {
                temp[i][j] -= factor * temp[k][j];
                result[i][j] -= factor * result[k][j];
            }
        }
    }

    return result;
}

Matrix power(const Matrix& A, int exponent)
{
    if (!validSquare(A))
        return {};

    if (exponent < 0) {
        if (exponent == std::numeric_limits<int>::min())
            return {};

        Matrix inv = inverse(A);

        if (inv.isEmpty())
            return {};

        return power(inv, -exponent);
    }

    Matrix result = createMatrix(A.size(), A.size());

    for (int i = 0; i < A.size(); ++i)
        result[i][i] = 1.0;

    Matrix base = A;
    int exp = exponent;

    while (exp > 0) {
        if (exp & 1)
            result = multiply(result, base);

        exp >>= 1;

        if (exp > 0)
            base = multiply(base, base);
    }

    return result;
}

SolverResult gaussianElimination(const Matrix& A, const QVector<double>& b)
{
    SolverResult result;

    if (!solveLinear(A, b, result.solution)) {
        result.message = "The system is invalid or singular.";
        return result;
    }

    result.success = true;
    result.message = "Solved using Gaussian elimination.";
    return result;
}

SolverResult cramerRule(const Matrix& A, const QVector<double>& b)
{
    SolverResult result;

    if (!isValidForLinearSystem(A, b)) {
        result.message = "A must be square and match vector b.";
        return result;
    }

    double detA = determinant(A);

    if (!std::isfinite(detA) || std::abs(detA) < EPS) {
        result.message = "Cramer's rule requires a non-singular matrix.";
        return result;
    }

    const int n = A.size();
    result.solution.resize(n);

    for (int col = 0; col < n; ++col) {
        Matrix replaced = A;

        for (int row = 0; row < n; ++row)
            replaced[row][col] = b[row];

        result.solution[col] = determinant(replaced) / detA;
    }

    result.success = true;
    result.message = "Solved using Cramer's rule.";
    return result;
}

SolverResult luDecomposition(const Matrix& A, const QVector<double>& b)
{
    SolverResult result;

    if (!isValidForLinearSystem(A, b)) {
        result.message = "A must be square and match vector b.";
        return result;
    }

    const int n = A.size();
    Matrix L = createMatrix(n, n);
    Matrix U = createMatrix(n, n);

    for (int i = 0; i < n; ++i) {
        for (int k = i; k < n; ++k) {
            double sum = 0.0;

            for (int j = 0; j < i; ++j)
                sum += L[i][j] * U[j][k];

            U[i][k] = A[i][k] - sum;
        }

        if (std::abs(U[i][i]) < EPS) {
            result.message = "LU decomposition failed: zero pivot.";
            return result;
        }

        L[i][i] = 1.0;

        for (int k = i + 1; k < n; ++k) {
            double sum = 0.0;

            for (int j = 0; j < i; ++j)
                sum += L[k][j] * U[j][i];

            L[k][i] = (A[k][i] - sum) / U[i][i];
        }
    }

    QVector<double> y(n, 0.0);
    for (int i = 0; i < n; ++i) {
        double sum = b[i];

        for (int j = 0; j < i; ++j)
            sum -= L[i][j] * y[j];

        y[i] = sum / L[i][i];
    }

    result.solution.fill(0.0, n);

    for (int i = n - 1; i >= 0; --i) {
        double sum = y[i];

        for (int j = i + 1; j < n; ++j)
            sum -= U[i][j] * result.solution[j];

        result.solution[i] = sum / U[i][i];
    }

    result.success = true;
    result.message = "Solved using LU decomposition.";
    return result;
}

double vectorError(const QVector<double>& oldVector,
                   const QVector<double>& newVector)
{
    if (oldVector.size() != newVector.size())
        return std::numeric_limits<double>::infinity();

    double error = 0.0;

    for (int i = 0; i < oldVector.size(); ++i)
        error = std::max(error, std::abs(newVector[i] - oldVector[i]));

    return error;
}

SolverResult jacobi(const Matrix& A, const QVector<double>& b,
                    const QVector<double>& initialGuess,
                    int maxIterations, double tolerance)
{
    // method 0: all updates use the previous iteration.
    return iterativeSolve(A, b, initialGuess, maxIterations,
                          tolerance, 0, 1.0);
}

SolverResult gaussSeidel(const Matrix& A, const QVector<double>& b,
                         const QVector<double>& initialGuess,
                         int maxIterations, double tolerance)
{
    return iterativeSolve(A, b, initialGuess, maxIterations,
                          tolerance, 1, 1.0);
}

SolverResult relaxation(const Matrix& A, const QVector<double>& b,
                        const QVector<double>& initialGuess,
                        double omega, int maxIterations, double tolerance)
{
    return iterativeSolve(A, b, initialGuess, maxIterations,
                          tolerance, 2, omega);
}

} // namespace MatrixLogic

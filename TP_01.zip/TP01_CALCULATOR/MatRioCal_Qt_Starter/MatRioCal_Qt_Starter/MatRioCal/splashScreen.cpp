#include "splashscreen.h"
#include <QPainter>
#include <QTimer>
#include <QApplication>

SplashScreen::SplashScreen(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(1350, 900);

    setWindowFlags(Qt::FramelessWindowHint | Qt::SplashScreen);

    setAttribute(Qt::WA_TranslucentBackground, false);

    QTimer::singleShot(3000, this, [this]() {
        emit splashFinished();
        close();
    });
}

void SplashScreen::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);

    painter.setRenderHint(QPainter::Antialiasing);

    painter.fillRect(rect(), QColor("#89CFF0"));

    QPen darkBluePen(QColor("#0A1C38"));
    darkBluePen.setWidth(4);
    painter.setPen(darkBluePen);

    const int cellSize = 115;
    const int startX = (width() - 3 * cellSize) / 2;
    const int startY = 145;

    for (int i = 0; i <= 3; ++i) {
        painter.drawLine(
            startX + i * cellSize,
            startY,
            startX + i * cellSize,
            startY + 3 * cellSize
            );

        painter.drawLine(
            startX,
            startY + i * cellSize,
            startX + 3 * cellSize,
            startY + i * cellSize
            );
    }

    QFont letterFont("Arial");
    letterFont.setPointSize(52);
    letterFont.setBold(true);

    painter.setFont(letterFont);
    painter.setPen(QColor("#0A1C38"));

    QString letters[3][3] = {
        {"M", "A", "T"},
        {"R", "I", "O"},
        {"C", "A", "L"}
    };

    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {

            QRect cell(
                startX + col * cellSize,
                startY + row * cellSize,
                cellSize,
                cellSize
                );

            painter.drawText(
                cell,
                Qt::AlignCenter,
                letters[row][col]
                );
        }
    }

    painter.setPen(QColor("#5B477D"));

    QFont symbolFont("Arial");
    symbolFont.setPointSize(34);
    symbolFont.setBold(true);

    painter.setFont(symbolFont);

    painter.drawText(
        QRect(startX - 80, startY + 25, 60, 60),
        Qt::AlignCenter,
        "×"
        );

    painter.drawText(
        QRect(startX + 3 * cellSize + 20, startY + 25, 60, 60),
        Qt::AlignCenter,
        "%"
        );

    painter.drawText(
        QRect(startX + 3 * cellSize + 15, startY + 195, 60, 60),
        Qt::AlignCenter,
        "÷"
        );

    painter.drawText(
        QRect(startX - 85, startY + 240, 60, 60),
        Qt::AlignCenter,
        "±"
        );

    QFont titleFont("Arial");
    titleFont.setPointSize(30);
    titleFont.setBold(true);

    painter.setFont(titleFont);
    painter.setPen(QColor("#0A1C38"));

    painter.drawText(
        QRect(0, 495, width(), 45),
        Qt::AlignCenter,
        "Matrix Operations Calculator"
        );

    QFont subtitleFont("Arial");
    subtitleFont.setPointSize(13);

    painter.setFont(subtitleFont);

    painter.drawText(
        QRect(0, 545, width(), 25),
        Qt::AlignCenter,
        "MatRioCal"
        );
}

#ifndef SPLASH_SCREEN_H
#define SPLASH_SCREEN_H

#include <QWidget>

class SplashScreen : public QWidget
{
     Q_OBJECT
public:
    explicit SplashScreen(QWidget *parent = nullptr);

protected:
    void paintEvent(QPaintEvent *event) override;

signals:
    void splashFinished();
};

#endif
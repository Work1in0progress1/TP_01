#include "matrix.h"
#include <cmath>
#include <stdexcept>
#include <algorithm>

Matrix::Matrix()
{
    rows = 0;
    cols = 0;
}

Matrix::Matrix(int rows, int cols)
{
    this->rows = rows;
    this->cols = cols;

    data.resize(rows);

    for (int i = 0; i < rows; ++i)
        data[i].resize(cols);
}

int Matrix::rowCount() const
{
    return rows;
}

int Matrix::columnCount() const
{
    return cols;
}

double Matrix::get(int row, int col) const
{
    return data[row][col];
}

void Matrix::set(int row, int col, double value)
{
    data[row][col] = value;
}

bool Matrix::isSquare() const
{
    return rows == cols;
}


// --------------------------------------------------
// Addition
// --------------------------------------------------

Matrix Matrix::addition(const Matrix &other) const
{
    if (rows != other.rows || cols != other.cols)
        throw std::invalid_argument("Matrices must have the same dimensions.");

    Matrix result(rows, cols);

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            result.data[i][j] = data[i][j] + other.data[i][j];
        }
    }

    return result;
}


// --------------------------------------------------
// Subtraction
// --------------------------------------------------

Matrix Matrix::subtraction(const Matrix &other) const
{
    if (rows != other.rows || cols != other.cols)
        throw std::invalid_argument("Matrices must have the same dimensions.");

    Matrix result(rows, cols);

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            result.data[i][j] = data[i][j] - other.data[i][j];
        }
    }

    return result;
}


// --------------------------------------------------
// Multiplication
// --------------------------------------------------

Matrix Matrix::multiply(const Matrix &other) const
{
    if (cols != other.rows)
        throw std::invalid_argument(
            "Number of columns of first matrix must equal "
            "number of rows of second matrix."
            );

    Matrix result(rows, other.cols);

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < other.cols; ++j)
        {
            double sum = 0;

            for (int k = 0; k < cols; ++k)
            {
                sum += data[i][k] * other.data[k][j];
            }

            result.data[i][j] = sum;
        }
    }

    return result;
}


// --------------------------------------------------
// Transpose
// --------------------------------------------------

Matrix Matrix::transpose() const
{
    Matrix result(cols, rows);

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            result.data[j][i] = data[i][j];
        }
    }

    return result;
}


// --------------------------------------------------
// Scalar multiplication
// --------------------------------------------------

Matrix Matrix::scalarMultiply(double scalar) const
{
    Matrix result(rows, cols);

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            result.data[i][j] = data[i][j] * scalar;
        }
    }

    return result;
}


// --------------------------------------------------
// Determinant
// --------------------------------------------------

double Matrix::determinant() const
{
    if (!isSquare())
        throw std::invalid_argument(
            "Determinant requires a square matrix."
            );

    int n = rows;

    if (n == 0)
        throw std::invalid_argument("Empty matrix.");

    if (n == 1)
        return data[0][0];

    if (n == 2)
    {
        return data[0][0] * data[1][1]
               - data[0][1] * data[1][0];
    }

    Matrix temp = *this;

    double det = 1.0;

    for (int i = 0; i < n; ++i)
    {
        int pivot = i;

        for (int j = i + 1; j < n; ++j)
        {
            if (std::abs(temp.data[j][i]) >
                std::abs(temp.data[pivot][i]))
            {
                pivot = j;
            }
        }

        if (std::abs(temp.data[pivot][i]) < 1e-12)
            return 0.0;

        if (pivot != i)
        {
            std::swap(temp.data[pivot], temp.data[i]);
            det *= -1;
        }

        det *= temp.data[i][i];

        for (int j = i + 1; j < n; ++j)
        {
            double factor =
                temp.data[j][i] / temp.data[i][i];

            for (int k = i; k < n; ++k)
            {
                temp.data[j][k] -=
                    factor * temp.data[i][k];
            }
        }
    }

    return det;
}


// --------------------------------------------------
// Trace
// --------------------------------------------------

double Matrix::trace() const
{
    if (!isSquare())
        throw std::invalid_argument(
            "Trace requires a square matrix."
            );

    double result = 0;

    for (int i = 0; i < rows; ++i)
        result += data[i][i];

    return result;
}


// --------------------------------------------------
// Rank
// --------------------------------------------------

int Matrix::rank() const
{
    Matrix temp = *this;

    int rank = 0;
    int currentRow = 0;

    for (int col = 0;
         col < cols && currentRow < rows;
         ++col)
    {
        int pivot = currentRow;

        for (int row = currentRow + 1;
             row < rows;
             ++row)
        {
            if (std::abs(temp.data[row][col]) >
                std::abs(temp.data[pivot][col]))
            {
                pivot = row;
            }
        }

        if (std::abs(temp.data[pivot][col]) < 1e-12)
            continue;

        std::swap(temp.data[pivot],
                  temp.data[currentRow]);

        for (int row = currentRow + 1;
             row < rows;
             ++row)
        {
            double factor =
                temp.data[row][col] /
                temp.data[currentRow][col];

            for (int k = col;
                 k < cols;
                 ++k)
            {
                temp.data[row][k] -=
                    factor * temp.data[currentRow][k];
            }
        }

        ++rank;
        ++currentRow;
    }

    return rank;
}


// --------------------------------------------------
// Inverse
// --------------------------------------------------

Matrix Matrix::inverse() const
{
    if (!isSquare())
        throw std::invalid_argument(
            "Inverse requires a square matrix."
            );

    int n = rows;

    Matrix augmented(n, 2 * n);

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            augmented.data[i][j] = data[i][j];
        }

        for (int j = 0; j < n; ++j)
        {
            augmented.data[i][j + n] =
                (i == j) ? 1.0 : 0.0;
        }
    }

    for (int i = 0; i < n; ++i)
    {
        int pivot = i;

        for (int j = i + 1; j < n; ++j)
        {
            if (std::abs(augmented.data[j][i]) >
                std::abs(augmented.data[pivot][i]))
            {
                pivot = j;
            }
        }

        if (std::abs(augmented.data[pivot][i]) < 1e-12)
            throw std::invalid_argument(
                "Matrix is singular and has no inverse."
                );

        std::swap(augmented.data[i],
                  augmented.data[pivot]);

        double pivotValue =
            augmented.data[i][i];

        for (int j = 0; j < 2 * n; ++j)
        {
            augmented.data[i][j] /= pivotValue;
        }

        for (int row = 0; row < n; ++row)
        {
            if (row == i)
                continue;

            double factor =
                augmented.data[row][i];

            for (int col = 0;
                 col < 2 * n;
                 ++col)
            {
                augmented.data[row][col] -=
                    factor * augmented.data[i][col];
            }
        }
    }

    Matrix result(n, n);

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            result.data[i][j] =
                augmented.data[i][j + n];
        }
    }

    return result;
}


// --------------------------------------------------
// Matrix power
// --------------------------------------------------

Matrix Matrix::power(int exponent) const
{
    if (!isSquare())
        throw std::invalid_argument(
            "Matrix power requires a square matrix."
            );

    if (exponent < 0)
        return inverse().power(-exponent);

    Matrix result(rows, cols);

    for (int i = 0; i < rows; ++i)
        result.data[i][i] = 1.0;

    Matrix base = *this;

    while (exponent > 0)
    {
        if (exponent % 2 == 1)
            result = result.multiply(base);

        base = base.multiply(base);

        exponent /= 2;
    }

    return result;
}
#include "open_window.h"
#include "splashscreen.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    SplashScreen splash;
    splash.show();

    Openwindow window;

    QObject::connect(&splash, &SplashScreen::splashFinished,
                     [&window]() {
                         window.show();
                     });

    return a.exec();
}
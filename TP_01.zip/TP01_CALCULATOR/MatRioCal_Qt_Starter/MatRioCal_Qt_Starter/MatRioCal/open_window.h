
#ifndef OPEN_WINDOW_H
#define OPEN_WINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QString>
#include <QLineEdit>
#include "matrix_logic.h"
class QTableWidget;
class QComboBox;
class QSpinBox;
class QLabel;
class QPushButton;

class Openwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Openwindow(QWidget *parent = nullptr);
    ~Openwindow() override = default;

private:
    QTableWidget *matrixTable = nullptr;
    QComboBox *matrixSelector = nullptr;
    QSpinBox *rowsSpin = nullptr;
    QSpinBox *colsSpin = nullptr;
    QLabel *matrixSizeLabel = nullptr;
    QLabel *statusLabel = nullptr;
    QLineEdit *inputDisplay;
    MatrixLogic::Matrix matrixA;
    MatrixLogic::Matrix matrixB;
    bool hasMatrixB = false;
     bool lightMode = false;
     bool darkMode;
    QString entryBuffer;
    QString pendingOperator;
    double firstOperand = 0.0;
    bool waitingForOperand = false;

    void resizeMatrixGrid(int rows, int cols);
    MatrixLogic::Matrix readMatrixFromTable(bool &ok);
    void writeMatrixToTable(const MatrixLogic::Matrix &matrix);
    void saveCurrentMatrix();
    void loadMatrix(const QString &name);
    MatrixLogic::Matrix &currentMatrix();

    void addMatrices();
    void subtractMatrices();
    void multiplyMatrices();
    void transposeMatrix();
    void scalarMultiplyMatrix();
    void calculateDeterminant();
    void calculateTrace();
    void calculateRank();
    void calculateInverse();
    void calculatePower();
    void createDiagonalMatrix();

    void insertNumber(const QString &number);
    void insertDecimal();
    void insertSign();
    void clearCurrentCell();
    void backspaceCurrentCell();
    void calculateInput();
    void setCurrentCellValue(double value);

    QVector<double> getVectorB(int size, bool &ok);
    void runSolver(const QString &method);
    void showVectorResult(const QString &title,
                          const MatrixLogic::SolverResult &result);
    void showMatrixResult(const QString &title,
                          const MatrixLogic::Matrix &result);
    void showMessage(const QString &title, const QString &message);
    void updateStatus(const QString &message);

    void connectOperationButtons();
    void connectInputButtons();
    void connectSolverButtons();
    void loadStyleSheet(const QString& fileName);
};

#endif

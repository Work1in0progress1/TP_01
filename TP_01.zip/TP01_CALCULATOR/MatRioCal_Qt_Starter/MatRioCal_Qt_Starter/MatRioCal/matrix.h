#ifndef MATRIX_H
#define MATRIX_H

#include <QVector>

class Matrix
{
private:
    QVector<QVector<double>> data;
    int rows;
    int cols;

public:
    // Constructors
    Matrix();
    Matrix(int rows, int cols);

    // Basic information
    int rowCount() const;
    int columnCount() const;

    // Access elements
    double get(int row, int col) const;
    void set(int row, int col, double value);

    // Basic matrix operations
    Matrix addition(const Matrix &other) const;
    Matrix subtraction(const Matrix &other) const;
    Matrix multiply(const Matrix &other) const;
    Matrix transpose() const;

    // Scalar operations
    Matrix scalarMultiply(double scalar) const;

    // Matrix analysis
    double determinant() const;
    double trace() const;
    int rank() const;

    // Advanced operations
    Matrix inverse() const;
    Matrix power(int exponent) const;

    // Utility
    bool isSquare() const;
};

#endif